package com.translator.minecraft;

import org.bukkit.plugin.java.JavaPlugin;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public class TranslationAPI {

    private final TranslateChat plugin;
    private final String apiUrl = "https://translate.marcosbrendon.com/translate";
    private final JSONParser jsonParser = new JSONParser();

    public TranslationAPI(TranslateChat plugin) {
        this.plugin = plugin;
    }

    /**
     * Traduz um texto de um idioma para outro de forma assíncrona
     * @param text Texto a ser traduzido
     * @param sourceLanguage Idioma de origem
     * @param targetLanguage Idioma de destino
     * @return CompletableFuture com o texto traduzido
     */
    public CompletableFuture<String> translate(String text, String sourceLanguage, String targetLanguage) {
        // Se os idiomas forem iguais, não precisa traduzir
        if (sourceLanguage.equalsIgnoreCase(targetLanguage)) {
            return CompletableFuture.completedFuture(text);
        }

        return CompletableFuture.supplyAsync(() -> {
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setDoOutput(true);

                // Criar o JSON para enviar
                JSONObject requestBody = new JSONObject();
                requestBody.put("q", text);
                requestBody.put("source", sourceLanguage);
                requestBody.put("target", targetLanguage);

                // Enviar a requisição
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = requestBody.toJSONString().getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                // Obter a resposta
                if (connection.getResponseCode() == 200) {
                    // Ler a resposta
                    java.util.Scanner scanner = new java.util.Scanner(connection.getInputStream(), StandardCharsets.UTF_8.name());
                    String responseBody = scanner.useDelimiter("\\A").next();
                    scanner.close();

                    // Parsear a resposta JSON
                    JSONObject responseJson = (JSONObject) jsonParser.parse(responseBody);
                    String translatedText = (String) responseJson.get("translatedText");
                    
                    return translatedText;
                } else {
                    plugin.getLogger().warning("Erro ao traduzir texto. Código de resposta: " + connection.getResponseCode());
                    return text; // Retorna o texto original em caso de erro
                }
            } catch (IOException | ParseException e) {
                plugin.getLogger().warning("Erro ao traduzir texto: " + e.getMessage());
                return text; // Retorna o texto original em caso de erro
            }
        });
    }

    /**
     * Detecta o idioma de um texto (implementação simplificada)
     * @param text Texto para detectar o idioma
     * @return Código do idioma detectado (padrão: pt-br)
     */
    public String detectLanguage(String text) {
        // Em uma implementação real, isso chamaria uma API de detecção de idioma
        // Por simplicidade, vamos assumir que o idioma padrão é pt-br
        return plugin.getConfig().getString("default-language", "pt-br");
    }
}
