package com.translator.minecraft;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class ChatListener implements Listener {

    private final TranslateChat plugin;

    public ChatListener(TranslateChat plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        // Cancelar o evento original para controlar a exibição das mensagens
        event.setCancelled(true);
        
        Player sender = event.getPlayer();
        String originalMessage = event.getMessage();
        
        // Detectar o idioma da mensagem original
        String sourceLanguage = plugin.getTranslationAPI().detectLanguage(originalMessage);
        
        // Mapa para armazenar as traduções por idioma (para evitar traduções duplicadas)
        Map<String, CompletableFuture<String>> translations = new HashMap<>();
        
        // Para cada jogador online, traduzir a mensagem para seu idioma preferido
        for (Player recipient : plugin.getServer().getOnlinePlayers()) {
            String targetLanguage = plugin.getPlayerLanguage(recipient);
            
            // Verificar se já temos uma tradução em andamento para este idioma
            if (!translations.containsKey(targetLanguage)) {
                // Iniciar nova tradução
                translations.put(targetLanguage, 
                    plugin.getTranslationAPI().translate(originalMessage, sourceLanguage, targetLanguage));
            }
            
            // Quando a tradução estiver pronta, enviar a mensagem para o jogador
            translations.get(targetLanguage).thenAccept(translatedText -> {
                // Formato da mensagem: [Jogador] Mensagem traduzida (Idioma original: xx)
                String formattedMessage = String.format("§7[%s] §f%s §7(Idioma original: %s)", 
                    sender.getDisplayName(), translatedText, sourceLanguage);
                
                recipient.sendMessage(formattedMessage);
            });
        }
        
        // Garantir que todas as traduções sejam concluídas (para logs ou outros propósitos)
        CompletableFuture.allOf(translations.values().toArray(new CompletableFuture[0]))
            .exceptionally(ex -> {
                plugin.getLogger().warning("Erro ao processar traduções: " + ex.getMessage());
                return null;
            });
    }
}
